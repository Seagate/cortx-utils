-- |
-- Copyright : (C) 2013 Xyratex Technology Limited.
-- License   : All rights reserved.

{-# LANGUAGE PackageImports #-}
module Control.Distributed.Process.Internal.Types
  ( module DP ) where

import "distributed-process" Control.Distributed.Process.Internal.Types as DP
