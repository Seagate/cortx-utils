-- |
-- Copyright : (C) 2015 Seagate Technology Limited.
-- License   : All rights reserved.

{-# LANGUAGE PackageImports #-}
module Control.Distributed.Process.Internal.StrictMVar
  ( module DP ) where

import "distributed-process" Control.Distributed.Process.Internal.StrictMVar as DP
