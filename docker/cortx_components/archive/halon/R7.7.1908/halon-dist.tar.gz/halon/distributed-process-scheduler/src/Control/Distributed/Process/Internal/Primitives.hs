{-# LANGUAGE PackageImports #-}
module Control.Distributed.Process.Internal.Primitives
  ( getNodeStats
  , NodeStats(..)
  , SayMessage(..)
  ) where

import "distributed-process" Control.Distributed.Process.Internal.Primitives
