Introduction
============

The Halon system consists of both command line tools and
a library that can be used together with deployment-specific
components to ensure the high availability of a distributed
application.

These libraries provide generic tools for building a High Availability
application.

Installation
============

XXX

Features
========

Generic components
------------------

* Networking
* Node agent
* Recovery supervisor
* Replicator
* Resource graph
