//
// Copyright : (C) 2013 Xyratex Technology Limited.
// License   : All rights reserved.
//

#pragma once

/**
   Extended opcodes complementing M0_RPC_OPCODES.
*/
#define RPCLITE_EPOCH_OPCODE       1000
#define RPCLITE_EPOCH_REPLY_OPCODE 1001
