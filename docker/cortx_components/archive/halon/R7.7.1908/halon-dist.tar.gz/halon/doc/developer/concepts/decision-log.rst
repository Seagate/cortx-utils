Concept: Decision Log
=====================

The decision log provides a detailed log for the rules running inside the
recovery coordinator. They provide a general view of the decisions being taken
by Halon, as well as a picture of what's happening in the cluster as a whole.

Design
------

See `rfc/018-logging-redux.md`.
