{-# LANGUAGE ScopedTypeVariables #-}
-- |
-- Copyright : (C) 2016 Xyratex Technology Limited.
-- License   : All rights reserved.
--
module HA.RecoveryCoordinator.RC
  ( module HA.RecoveryCoordinator.RC.Subscription
  ) where

import HA.RecoveryCoordinator.RC.Subscription
