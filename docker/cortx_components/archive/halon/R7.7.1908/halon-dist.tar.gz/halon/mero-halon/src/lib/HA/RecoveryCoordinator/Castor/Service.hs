-- |
-- Copyright : (C) 2016 Seagate Technology Limited.
-- License   : All rights reserved.
--

module HA.RecoveryCoordinator.Castor.Service
  ( module HA.RecoveryCoordinator.Castor.Service.Rules
  ) where

import HA.RecoveryCoordinator.Castor.Service.Rules
